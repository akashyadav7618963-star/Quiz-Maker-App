Quiz Maker Android project

This project wraps the offline Quiz Maker web app in an Android WebView.
It is built in the cloud using GitHub Actions; Android Studio is not required on the user's Windows 7 PC.

Build:
- Add the workflow file from the separate instructions to .github/workflows/android.yml in your GitHub repository.
- Upload this project's contents (not the containing folder) to the repository root.
- Push/commit changes.
- Open Actions and download the app-debug.apk artifact after the workflow succeeds.

App data is stored locally in the app's WebView storage on the phone.
